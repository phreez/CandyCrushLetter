package com.charles;

public interface ICandyCrushLetter {
   void process(String input);
}
